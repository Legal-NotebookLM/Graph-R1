1. Demographic Diversity

15 salaried employees

10 self-employed

5 gig workers (Zomato, Swiggy, Rapido)

10 rural borrowers

10 Tier-1 city borrowers

Mix gender + age range 21–55

2. Loan Type Diversity

20 Two-wheeler

10 Personal

10 Consumer durable

5 Business loans

5 Gold loans

3. Default Reason Diversity

10 job loss

7 medical reason

8 intentional evasion

10 relocation

5 salary cut

5 business closure

5 fraud/overstating income

4. Case Stage Diversity

7 soft reminder

7 field visit

7 recall notice

10 arbitration process

5 midway arbitration

7 award passed

7 execution stage

Mix these to get 50 unique cases.